﻿namespace start_page
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStudpage = new System.Windows.Forms.Button();
            this.btnLectpage = new System.Windows.Forms.Button();
            this.btnExppage = new System.Windows.Forms.Button();
            this.lblusername = new System.Windows.Forms.Label();
            this.lblpass = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnAutorize = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnStudpage
            // 
            this.btnStudpage.Location = new System.Drawing.Point(198, 227);
            this.btnStudpage.Name = "btnStudpage";
            this.btnStudpage.Size = new System.Drawing.Size(75, 23);
            this.btnStudpage.TabIndex = 0;
            this.btnStudpage.Text = "Student";
            this.btnStudpage.UseVisualStyleBackColor = true;
            this.btnStudpage.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLectpage
            // 
            this.btnLectpage.BackColor = System.Drawing.Color.Transparent;
            this.btnLectpage.Location = new System.Drawing.Point(393, 227);
            this.btnLectpage.Name = "btnLectpage";
            this.btnLectpage.Size = new System.Drawing.Size(75, 23);
            this.btnLectpage.TabIndex = 3;
            this.btnLectpage.Text = "Lector";
            this.btnLectpage.UseVisualStyleBackColor = false;
            this.btnLectpage.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnExppage
            // 
            this.btnExppage.Location = new System.Drawing.Point(293, 227);
            this.btnExppage.Name = "btnExppage";
            this.btnExppage.Size = new System.Drawing.Size(75, 23);
            this.btnExppage.TabIndex = 2;
            this.btnExppage.Text = "Expert";
            this.btnExppage.UseVisualStyleBackColor = true;
            this.btnExppage.Click += new System.EventHandler(this.btnExppage_Click);
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Location = new System.Drawing.Point(156, 66);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(57, 13);
            this.lblusername.TabIndex = 4;
            this.lblusername.Text = "UserName";
            // 
            // lblpass
            // 
            this.lblpass.AutoSize = true;
            this.lblpass.Location = new System.Drawing.Point(156, 108);
            this.lblpass.Name = "lblpass";
            this.lblpass.Size = new System.Drawing.Size(53, 13);
            this.lblpass.TabIndex = 5;
            this.lblpass.Text = "Password";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(217, 63);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(217, 105);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 7;
            // 
            // btnAutorize
            // 
            this.btnAutorize.Location = new System.Drawing.Point(242, 151);
            this.btnAutorize.Name = "btnAutorize";
            this.btnAutorize.Size = new System.Drawing.Size(75, 23);
            this.btnAutorize.TabIndex = 8;
            this.btnAutorize.Text = "Login";
            this.btnAutorize.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(225, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 24);
            this.label1.TabIndex = 9;
            this.label1.Text = "Welcome !";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(484, 262);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAutorize);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblpass);
            this.Controls.Add(this.lblusername);
            this.Controls.Add(this.btnExppage);
            this.Controls.Add(this.btnLectpage);
            this.Controls.Add(this.btnStudpage);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StartPage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStudpage;
        private System.Windows.Forms.Button btnLectpage;
        private System.Windows.Forms.Button btnExppage;
        private System.Windows.Forms.Label lblusername;
        private System.Windows.Forms.Label lblpass;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnAutorize;
        private System.Windows.Forms.Label label1;
    }
}

