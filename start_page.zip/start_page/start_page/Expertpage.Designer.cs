﻿namespace start_page
{
    partial class Expertpage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBacktomain = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBacktomain
            // 
            this.btnBacktomain.CausesValidation = false;
            this.btnBacktomain.Location = new System.Drawing.Point(12, 12);
            this.btnBacktomain.Name = "btnBacktomain";
            this.btnBacktomain.Size = new System.Drawing.Size(94, 23);
            this.btnBacktomain.TabIndex = 3;
            this.btnBacktomain.Text = "Back to main";
            this.btnBacktomain.UseVisualStyleBackColor = true;
            this.btnBacktomain.Click += new System.EventHandler(this.btnBacktomain_Click);
            // 
            // Expertpage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.btnBacktomain);
            this.MaximizeBox = false;
            this.Name = "Expertpage";
            this.Text = "Expertpage";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBacktomain;
    }
}