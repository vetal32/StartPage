﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace start_page
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Studentpage sp = new Studentpage();
            sp.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Lectorpage lp = new Lectorpage();
            lp.Show();
        }

        private void btnExppage_Click(object sender, EventArgs e)
        {
            this.Hide();
            Expertpage ex = new Expertpage();
            ex.Show();
        }

           

    }
}
